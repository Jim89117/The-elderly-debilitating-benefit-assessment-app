package com.e.a20201202;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


public class Recognize_weight extends AppCompatActivity {

    private Button confirm;
    private EditText input_weight;

    //database setting
    private enum handle_type
    {
        Insert,Update,Delete
    }

    private int nowUID = -1;

    private ArrayList<ContactInfo> myTelephoneBook = new ArrayList<ContactInfo>();
    private ArrayList<String> totalListViewData = new ArrayList<String>();
    private ArrayAdapter listAdapter;
    private DBHelper myDBHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recognize_weight);
        //設定隱藏標題
        getSupportActionBar().hide();
        //設定隱藏狀態
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);

        //database
        setInit();

        findObj();
        buttonClickEvent();


    }

    void findObj(){
        confirm = findViewById(R.id.confirm);
        input_weight = findViewById(R.id.input_weight);
    }

    public void buttonClickEvent() {
        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                input_weight.getText().toString();
//                input_weight.setText("");
                handleContactInfo(handle_type.Insert);
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy年MM月dd日HH:mm:ss");

                Date curDate = new Date(System.currentTimeMillis()) ; // 獲取當前時間

                String str = formatter.format(curDate);
//                Toast.makeText(Recognize_weight.this,str,Toast.LENGTH_SHORT).show();
//                for(int i=0;i<myTelephoneBook.size(); i++) {
//                    ContactInfo eachPersonContactInfo = myTelephoneBook.get(i);
//                    Toast.makeText(Recognize_weight.this,eachPersonContactInfo.getUserName()+" "+eachPersonContactInfo.getPhoneNumber(),Toast.LENGTH_SHORT).show();
//                }
            }
        });
    }

    public void setInit(){
        myDBHelper = new DBHelper(this);
        myTelephoneBook.addAll(myDBHelper.getTotalContactInfo());
    }

    public void handleContactInfo(handle_type type){
        String weight = input_weight.getText().toString() ;
//        String phone = password.getText().toString();
        String datatype = "weight";

        if(isLegalForOperation(datatype ,weight)){
//            account.setText("");
//            password.setText("");
            input_weight.setText("");
            this.myDBHelper.insertToLocalDB(datatype,weight);
//            switch (type){
//                case Insert:
//                    this.myDBHelper.insertToLocalDB(datatype,weight);
//                    break;
//                case Delete:
//                    this.myDBHelper.deleteFromLocalDB(this.nowUID);
//                    break;
//                case Update:
//                    this.myDBHelper.updateToLocalDB(this.nowUID,datatype,weight);
//                    break;
//                default:
//                    break;
//            }
            this.myTelephoneBook.clear();
            this.myTelephoneBook.addAll(myDBHelper.getTotalContactInfo());

        }
        else{
            Toast.makeText(this,"您的資料不完整，請重試",Toast.LENGTH_LONG).show();
        }
    }

    public boolean isLegalForOperation(String name,String phone){
        if(name.length() == 0 || phone.length() == 0)
            return false;
        else
            return true;
    }
}