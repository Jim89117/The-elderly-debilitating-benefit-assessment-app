package com.e.a20201202;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Locale;

public class show_analyze_page2 extends AppCompatActivity {
    Button finish;
    TextView result;
    int flag = 0,s = 0,w1 = 0,w2 = 0,m=0;//判斷前期/中期
    String ss = "", ww = "", mm = "";
    private TextToSpeech talk_object;
    String Chi_recog_result = "";
    String judge_result = "";

    //database setting
    private enum handle_type
    {
        Insert,Update,Delete
    }

    private int nowUID = -1;

    private ArrayList<ContactInfo> myTelephoneBook = new ArrayList<ContactInfo>();
    private ArrayList<String> totalListViewData = new ArrayList<String>();
    private ArrayAdapter listAdapter;
    private DBHelper myDBHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_analyze_page2);
        //設定隱藏標題
        getSupportActionBar().hide();
        //設定隱藏狀態
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);
        findobject();
        getdata();
        settext();
    }
    public void findobject(){
        result = findViewById(R.id.result);
    }
    public TextToSpeech initTalkObject(){
        talk_object = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status == TextToSpeech.SUCCESS){
                    Log.d("success","success");
                    talk_object.setPitch((float)1.0);
                    talk_object.setSpeechRate((float)1.0);
                    Locale locale = Locale.TAIWAN;
                    if(talk_object.isLanguageAvailable(locale) >= TextToSpeech.LANG_AVAILABLE){
                        talk_object.setLanguage(locale);
                    }
                }
            }
        });
        return talk_object;
    }
    public void botSayChinese(final String s){
        talk_object = initTalkObject();
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                talk_object.speak(s,TextToSpeech.QUEUE_FLUSH,null);
                while (talk_object.isSpeaking()){}
            }
        },2000);
    }
    public void getdata(){
        flag = 0;
        int time = 0;
        //getdata
        myDBHelper = new DBHelper(this);
        myTelephoneBook.addAll(myDBHelper.getTotalContactInfo());
        for(int i=0;i<myTelephoneBook.size(); i++) {
            ContactInfo eachPersonContactInfo = myTelephoneBook.get(i);
            if(eachPersonContactInfo.getUserName() == "speed"){
                ss = "speed";
                s = Integer.parseInt(eachPersonContactInfo.getPhoneNumber());
            }
            else if(eachPersonContactInfo.getUserName() == "mood"){
                mm = "mood";
                m = Integer.parseInt(eachPersonContactInfo.getPhoneNumber());
            }

            else if(eachPersonContactInfo.getUserName() == "weight"){
                w1 = Integer.parseInt(eachPersonContactInfo.getPhoneNumber());
               if(time == 1){
                   w2 = w1;
               }
                if(time > 1){
                    int tmp = w1;
                    w1 = w2;
                    w2 = tmp;
                }
                ww = "weight";
            }

        }
        //判斷
        if(ss == "speed" && s <= 80 ){
            flag += 1;
        }
        else if(mm == "mood" && m >= 3){
            flag += 1;
        }
        else if(ww == "weight" && (w2 - w1) > 5){
            flag += 1;
        }
        if(flag <= 2){
            judge_result = "您符合了衰弱指標裡的1至2項，屬於衰弱前期，建議您先從調整飲食、運動開始，並且每年追蹤各項數據";
        }
        else {
            judge_result = "您符合了衰弱指標裡超過3項的指標，已符合衰弱表現，建議您盡快前往老人醫學門診進行整體性評估，早期治療有助於延緩衰弱速度";
        }
        talk_object = initTalkObject();
        botSayChinese(judge_result);
    }
    public void settext(){
        result.setText(judge_result);
    }
}