package com.e.a20201202;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.util.Locale;

public class Write_sheet extends AppCompatActivity {
    Button judge_rule, back;
    private TextToSpeech talk_object;
    String Chi_recog_result = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_write_sheet);
//        setContentView(R.layout.activity_show_analyze_page1);
        //設定隱藏標題
        getSupportActionBar().hide();
        //設定隱藏狀態
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);
        findobject();
        buttonevent();
    }
    public TextToSpeech initTalkObject(){
        talk_object = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status == TextToSpeech.SUCCESS){
                    Log.d("success","success");
                    talk_object.setPitch((float)1.0);
                    talk_object.setSpeechRate((float)1.0);
                    Locale locale = Locale.TAIWAN;
                    if(talk_object.isLanguageAvailable(locale) >= TextToSpeech.LANG_AVAILABLE){
                        talk_object.setLanguage(locale);
                    }
                }
            }
        });
        return talk_object;
    }
    public void botSayChinese(final String s){
        talk_object = initTalkObject();
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                talk_object.speak(s,TextToSpeech.QUEUE_FLUSH,null);
                while (talk_object.isSpeaking()){}
            }
        },2000);
    }
    public void findobject(){
        back = findViewById(R.id.back);
        judge_rule = findViewById(R.id.judge_rule);
    }
    public void buttonevent(){
        judge_rule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                talk_object = initTalkObject();
                String rule = "速度緩慢指得是行走6公尺時間大於5秒，即每秒小於0.8公尺，體重減輕指得是，體重較前一年減輕超過5公斤，疲憊指得是過去一周超過三天，做事情感覺費力或無法出門。";
                botSayChinese(rule);
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}