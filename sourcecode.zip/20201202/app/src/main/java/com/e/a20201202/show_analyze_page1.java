package com.e.a20201202;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class show_analyze_page1 extends AppCompatActivity {
    Button goto_pic,back;
    int flag = 0;
    String s = "",w1 = "",w2 = "",m="";//判斷前期/中期
    String ss = "", ww = "", mm = "";
    TextView speed_int,strength_int,weight_int,tired_int,activity_int;
    private TextToSpeech talk_object;
    String Chi_recog_result = "";

    //database setting
    private enum handle_type
    {
        Insert,Update,Delete
    }

    private int nowUID = -1;

    private ArrayList<ContactInfo> myTelephoneBook = new ArrayList<ContactInfo>();
    private ArrayList<String> totalListViewData = new ArrayList<String>();
    private ArrayAdapter listAdapter;
    private DBHelper myDBHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_analyze_page1);
        //設定隱藏標題
        getSupportActionBar().hide();
        //設定隱藏狀態
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);
        findobject();
        getdata();
        settext();

        buttonevent();
    }
    public void findobject(){
        goto_pic = findViewById(R.id.goto_page2);
        back = findViewById(R.id.back);
        speed_int = findViewById(R.id.speed_int);
        //strength_int = findViewById(R.id.strength_int);
        weight_int = findViewById(R.id.weight_int);
        tired_int = findViewById(R.id.tired_int);
        //activity_int = findViewById(R.id.activity_int);
    }
    public TextToSpeech initTalkObject(){
        talk_object = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status == TextToSpeech.SUCCESS){
                    Log.d("success","success");
                    talk_object.setPitch((float)1.0);
                    talk_object.setSpeechRate((float)1.0);
                    Locale locale = Locale.TAIWAN;
                    if(talk_object.isLanguageAvailable(locale) >= TextToSpeech.LANG_AVAILABLE){
                        talk_object.setLanguage(locale);
                    }
                }
            }
        });
        return talk_object;
    }
    public void botSayChinese(final String s){
        talk_object = initTalkObject();
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                talk_object.speak(s,TextToSpeech.QUEUE_FLUSH,null);
                while (talk_object.isSpeaking()){}
            }
        },2000);
    }
    public void getdata(){

        int time = 0;
        myDBHelper = new DBHelper(this);
        myTelephoneBook.addAll(myDBHelper.getTotalContactInfo());
        for(int i=0;i<myTelephoneBook.size(); i++) {
            ContactInfo eachPersonContactInfo = myTelephoneBook.get(i);
//            Toast.makeText(show_analyze_page1.this,eachPersonContactInfo.getUserName()+)
            if(eachPersonContactInfo.getUserName().equals("speed") ){
                ss = "speed";
                s = eachPersonContactInfo.getPhoneNumber();
            }
            else if(eachPersonContactInfo.getUserName().equals("mood")){
                mm = "mood";
                m = eachPersonContactInfo.getPhoneNumber();
            }

            else if(eachPersonContactInfo.getUserName().equals("weight")){
                w2 =w1;
                w1 = eachPersonContactInfo.getPhoneNumber();
                if(time == 0){
                    w2 = "0";
                    time++;
                }
                else{
                    w2 = Integer.toString(Integer.parseInt(w1)-Integer.parseInt(w2));
                }
                ww = "weight";
//                time++;
            }

        }
    }
    public void settext(){
        speed_int.setText(s+"公分/秒");
        weight_int.setText(w2 + "公斤");
        tired_int.setText(m + "級");
    }
    public void buttonevent(){
        goto_pic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(show_analyze_page1.this,show_analyze_page2.class);
                startActivity(intent);
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}