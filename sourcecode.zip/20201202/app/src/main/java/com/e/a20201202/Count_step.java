package com.e.a20201202;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Count_step extends AppCompatActivity {


    private float LastX, LastY, LastZ;
    double S;
    int step_num=0;
    private boolean record = true;
    private Button pressMe, startbutton;
    private TextView show_step_num;
    private SensorManager sm;
    private Sensor sensor;
    private long LastTime, startTime;
    private boolean start_flag = false;
    private int rec_flag, step = 45;
    private float var;

    //database setting
    private enum handle_type
    {
        Insert,Update,Delete
    }

    private int nowUID = -1;

    private ArrayList<ContactInfo> myTelephoneBook = new ArrayList<ContactInfo>();
    private ArrayList<String> totalListViewData = new ArrayList<String>();
    private ArrayAdapter listAdapter;
    private DBHelper myDBHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_count_step);
        //設定隱藏標題
        getSupportActionBar().hide();
        //設定隱藏狀態
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);

        setInit();

        findObj();
        try_to_implement();
        buttonClickEvent();

    }

    public void findObj(){
//        pressMe = findViewById(R.id.pressMe);
        show_step_num = findViewById(R.id.show_step_num);
        startbutton = findViewById(R.id.start);
    }

    private SensorEventListener SensorListener = new SensorEventListener(){
        public void onSensorChanged(SensorEvent event){
            if (!start_flag)
                return;
            long currentTime = System.currentTimeMillis();
            long xTime = currentTime - LastTime;

            float x = event.values[0];
            float y = event.values[1];
            float z = event.values[2];
            int posx = Float.floatToIntBits(x)/1000000;
            int posy = Float.floatToIntBits(y)/1000000;
            int posz = Float.floatToIntBits(z)/1000000;

            if(currentTime-LastTime>1000) {
                //每當觸發一次步數，須等一秒才能再次觸發。
                record = true;
            }
            if(rec_flag == 1) {
                LastX = posx;
                rec_flag =2;
            }
            if(Math.abs(posz - LastZ) >13 && record == true){
//                show_step_num.setText(show_step_num.getText()+Float.toString(posz-LastZ));
                //當Z軸(即手機與地面垂直時的上下擺幅)震動幅度達一定大小，記錄一次步數
                if(rec_flag ==2) {
                    step = Float.floatToIntBits(posx - LastX);
                    rec_flag =0;
                }
                if (LastZ!=0)
                    step_num++;
                LastX = posx;
                LastY = posy;
                LastZ = posz;
                LastTime = currentTime;
                record = false;
            }
            show_step_num.setText("當前步數: \n "+step_num+" 步\n 步行距離約: \n "+(step_num*step)+" cm \n (預設一步為45cm)");
        }
        public void onAccuracyChanged(Sensor sensor , int accuracy){
        }
    };

    public void try_to_implement(){
        sm = (SensorManager) this.getSystemService(Context.SENSOR_SERVICE);

        sensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        sm.registerListener(SensorListener, sensor,SensorManager.SENSOR_DELAY_GAME);


    }

    public void buttonClickEvent() {
//        pressMe.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
////                step_num=0;
//                rec_flag = 3;
//
//            }
//        });
        startbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(start_flag) {
                    start_flag = false;
                    startbutton.setText("開始測量");

                    SimpleDateFormat formatter = new SimpleDateFormat("yyyy年MM月dd日HH:mm:ss");

                    Date curDate = new Date(System.currentTimeMillis()) ; // 獲取當前時間

                    String str = formatter.format(curDate);
//                    Toast.makeText(Count_step.this,str,Toast.LENGTH_SHORT).show();
                    long divide = ((System.currentTimeMillis() - startTime)/(1000));
                    if(divide == 0){
                        step_num=0;
                        return;
                    }
                    handleContactInfo(handle_type.Insert);
//                    (step_num*step)/((System.currentTimeMillis() - startTime)/(1000))
//                    Toast.makeText(Count_step.this,Long.toString((step_num*step)/divide),Toast.LENGTH_SHORT).show();
//                    for(int i=0;i<myTelephoneBook.size(); i++) {
//                        ContactInfo eachPersonContactInfo = myTelephoneBook.get(i);
//                        Toast.makeText(Count_step.this,eachPersonContactInfo.getUserName()+" "+eachPersonContactInfo.getPhoneNumber(),Toast.LENGTH_SHORT).show();
//                    }
                    step_num=0;

                }
                else{
                    start_flag = true;
                    startbutton.setText("停止測量，並記錄");
                    startTime = System.currentTimeMillis();

                }


//                Toast.makeText(Count_step.this, "HI", Toast.LENGTH_SHORT).show();

            }
        });
    }

    // SQL start
    public void setInit(){
        myDBHelper = new DBHelper(this);
        myTelephoneBook.addAll(myDBHelper.getTotalContactInfo());
    }

    public void handleContactInfo(Count_step.handle_type type){
        String totalstep = Long.toString((step_num*step)/((System.currentTimeMillis() - startTime)/(1000))) ;
        String datatype = "speed";


        this.myDBHelper.insertToLocalDB(datatype,totalstep);

        this.myTelephoneBook.clear();
        this.myTelephoneBook.addAll(myDBHelper.getTotalContactInfo());

    }


}