package com.e.a20201202;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Locale;

public class Show_mood_result extends AppCompatActivity {
    TextView show_res;
    Button back;
    String str_result;
    private TextToSpeech talk_object;
    String Chi_recog_result = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_mood_result);
        //設定隱藏標題
        getSupportActionBar().hide();
        //設定隱藏狀態
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);
        findobject();
        getintent();
        settext();
//        buttonevent();
    }
    public void findobject(){
        show_res = findViewById(R.id.show_result);
//        back = findViewById(R.id.back);
    }
    public TextToSpeech initTalkObject(){
        talk_object = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status == TextToSpeech.SUCCESS){
                    Log.d("success","success");
                    talk_object.setPitch((float)1.0);
                    talk_object.setSpeechRate((float)1.0);
                    Locale locale = Locale.TAIWAN;
                    if(talk_object.isLanguageAvailable(locale) >= TextToSpeech.LANG_AVAILABLE){
                        talk_object.setLanguage(locale);
                    }
                }
            }
        });
        return talk_object;
    }
    public void botSayChinese(final String s){
        talk_object = initTalkObject();
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                talk_object.speak(s,TextToSpeech.QUEUE_FLUSH,null);
                while (talk_object.isSpeaking()){}
            }
        },2000);
    }
    public void getintent(){
        str_result = getIntent().getStringExtra("tmp_result");
        talk_object = initTalkObject();
        botSayChinese(str_result);
    }
    public void settext(){
        show_res.setText(show_res.getText() + str_result);
    }
//    public void buttonevent(){
//        back.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//            }
//        });
//    }
}