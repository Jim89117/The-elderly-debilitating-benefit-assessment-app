package com.e.a20201202;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class Mood_temperature extends AppCompatActivity {
    Button finish;
    Button mic1,mic2,mic3,mic4,mic5;
    EditText edi1,edi2,edi3,edi4,edi5;
    String s,result;
    private TextToSpeech talk_object;
    String Chi_recog_result = "";
    int e1,e2,e3,e4,e5,etotal;

    //database setting
    private enum handle_type
    {
        Insert,Update,Delete
    }

    private int nowUID = -1;

    private ArrayList<ContactInfo> myTelephoneBook = new ArrayList<ContactInfo>();
    private ArrayList<String> totalListViewData = new ArrayList<String>();
    private ArrayAdapter listAdapter;
    private DBHelper myDBHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mood_temperature);
        //設定隱藏標題
        getSupportActionBar().hide();
        //設定隱藏狀態
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);
        findobject();
//        getedi();

        //database
        setInit();

        buttonevent();
    }
    public TextToSpeech initTalkObject(){
        talk_object = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status == TextToSpeech.SUCCESS){
                    Log.d("success","success");
                    talk_object.setPitch((float)1.0);
                    talk_object.setSpeechRate((float)1.0);
                    Locale locale = Locale.TAIWAN;
                    if(talk_object.isLanguageAvailable(locale) >= TextToSpeech.LANG_AVAILABLE){
                        talk_object.setLanguage(locale);
                    }
                }
            }
        });
        return talk_object;
    }
    public void botSayChinese(final String s){
        talk_object = initTalkObject();
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                talk_object.speak(s,TextToSpeech.QUEUE_FLUSH,null);
                while (talk_object.isSpeaking()){}
            }
        },1500);
    }
    public void findobject(){
        finish = findViewById(R.id.finish_mood_sheet);
        edi1 = findViewById(R.id.edi1);
        edi2 = findViewById(R.id.edi2);
        edi3 = findViewById(R.id.edi3);
        edi4 = findViewById(R.id.edi4);
        edi5 = findViewById(R.id.edi5);

        mic1 = findViewById(R.id.mic_1);
        mic2 = findViewById(R.id.mic_2);
        mic3 = findViewById(R.id.mic_3);
        mic4 = findViewById(R.id.mic_4);
        mic5 = findViewById(R.id.mic_5);


    }
    public int getedi(){
//        s = edi1.getText().toString();
//        Toast.makeText(Mood_temperature.this,s,Toast.LENGTH_SHORT).show();
        e1 = Integer.parseInt(edi1.getText().toString());
////        s = edi2.getText().toString();
        e2 = Integer.parseInt(edi2.getText().toString());
////        s = edi3.getText().toString();
        e3 = Integer.parseInt(edi3.getText().toString());
////        s = edi4.getText().toString();
        e4 = Integer.parseInt(edi4.getText().toString());
////        s = edi5.getText().toString();
        e5 = Integer.parseInt(edi5.getText().toString());
        etotal = e1 + e2 + e3 + e4 + e5;
        if(e5>4 || e5<0 || e4>4 || e4<0 || e3>4 || e3<0 || e2>4 || e2<0 || e1>4 || e1<0 ) {
            return 1;
        }
        if(etotal >= 0 && etotal <= 5 ){
            result = "恭喜您身心狀況非常良好，請繼續保持哦";
        }
        else if(etotal >= 6 && etotal <= 9 ){
            result = "輕度情緒困擾，建議尋求紓壓管道或接受心理專業諮詢";
        }
        else if(etotal >= 10 && etotal <= 14 ){
            result = "中度情緒困擾，建議尋求心理專業諮詢接受進一步評估";
        }
        else {
            result = "重度情緒困擾，建議尋求精神科專業醫生諮詢";
        }
        return 0;
    }
    public void buttonevent(){
        mic1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                talk_object = initTalkObject();
                Chi_recog_result = "感覺緊張不安";
                botSayChinese(Chi_recog_result);
            }
        });
        mic2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                talk_object = initTalkObject();
                Chi_recog_result = "感覺容易苦惱動怒";
                botSayChinese(Chi_recog_result);
            }
        });
        mic3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                talk_object = initTalkObject();
                Chi_recog_result = "感覺憂鬱心情低落";
                botSayChinese(Chi_recog_result);
            }
        });
        mic4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                talk_object = initTalkObject();
                Chi_recog_result = "不想做任何事，不想動";
                botSayChinese(Chi_recog_result);
            }
        });
        mic5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                talk_object = initTalkObject();
                Chi_recog_result = "睡眠困難，易醒或難，南以入睡";
                botSayChinese(Chi_recog_result);
            }
        });
        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(getedi() == 1){
                    Toast.makeText(Mood_temperature.this, "請確認輸入資料是否正確", Toast.LENGTH_SHORT).show();
                    return;
                }
                handleContactInfo(handle_type.Insert);
//                for(int i=0;i<myTelephoneBook.size(); i++) {
//                    ContactInfo eachPersonContactInfo = myTelephoneBook.get(i);
//                    Toast.makeText(Mood_temperature.this,eachPersonContactInfo.getUserName()+" "+eachPersonContactInfo.getPhoneNumber(),Toast.LENGTH_SHORT).show();
//                }

                Intent intent = new Intent();
                intent.putExtra("tmp_result",result);
                intent.setClass(Mood_temperature.this,Show_mood_result.class);
                startActivity(intent);
            }
        });
    }

    public void setInit(){
        myDBHelper = new DBHelper(this);
        myTelephoneBook.addAll(myDBHelper.getTotalContactInfo());
    }

    public void handleContactInfo(handle_type type){
//        String weight = input_weight.getText().toString() ;
//        String phone = password.getText().toString();
        String datatype = "mood";
        String score = Integer.toString(e4);
        if(isLegalForOperation(datatype ,score)){
//            account.setText("");
//            password.setText("");
//            input_weight.setText("");
            this.myDBHelper.insertToLocalDB(datatype,score);
//            switch (type){
//                case Insert:
//                    this.myDBHelper.insertToLocalDB(datatype,weight);
//                    break;
//                case Delete:
//                    this.myDBHelper.deleteFromLocalDB(this.nowUID);
//                    break;
//                case Update:
//                    this.myDBHelper.updateToLocalDB(this.nowUID,datatype,weight);
//                    break;
//                default:
//                    break;
//            }
            this.myTelephoneBook.clear();
            this.myTelephoneBook.addAll(myDBHelper.getTotalContactInfo());

        }
        else{
            Toast.makeText(this,"您的資料不完整，請重試",Toast.LENGTH_LONG).show();
        }
    }

    public boolean isLegalForOperation(String name,String phone){
        if(name.length() == 0 || phone.length() == 0)
            return false;
        else
            return true;
    }
}