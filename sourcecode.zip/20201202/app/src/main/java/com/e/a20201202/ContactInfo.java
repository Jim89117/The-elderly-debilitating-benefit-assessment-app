package com.e.a20201202;


public class ContactInfo {
    private int uID;
    private String userName;
    private String phoneNumber;
    private String dataDate;

    public void init(int id , String name , String phone){
        this.uID = id;
        this.userName = name;
        this.phoneNumber = phone;
//        this.dataDate = date;
    }

    public int getUserID(){
        return this.uID;
    }
    public String getUserName(){
        return this.userName;
    }
    public String getPhoneNumber(){
        return this.phoneNumber;
    }
//    public String getDataDate(){
//        return this.dataDate;
//    }
}
