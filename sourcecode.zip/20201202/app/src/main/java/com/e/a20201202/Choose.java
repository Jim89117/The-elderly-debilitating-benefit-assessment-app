package com.e.a20201202;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.tts.Voice;
import android.view.View;
import android.widget.Button;
import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class Choose extends AppCompatActivity {
    Button count_step,rec_weight,write_sheet,mood_temperature,analize;
    Button mic_choose_tem,mic_choose_count,mic_choose_weight,mic_choose_write,mic_choose_analyze;
    ImageView mic_choose_tem_red,mic_choose_count_red,mic_choose_weight_red,mic_choose_write_red,mic_choose_analyze_red;
    private SpeechRecognizer recognizer;
    private TextToSpeech talk_object;
    String Chi_recog_result = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose);
        //設定隱藏標題
        getSupportActionBar().hide();
        //設定隱藏狀態
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);
        checkpermission();
        findobject();
        buttonevent();
    }
    public void checkpermission(){
        int recordPermission = ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO);
        if(recordPermission != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(Choose.this,new  String[]{Manifest.permission.RECORD_AUDIO},1);
        }
    }
    public void findobject(){
        mood_temperature = findViewById(R.id.mood_temperature);
        count_step = findViewById(R.id.count_step);
        rec_weight = findViewById(R.id.recog_weight);
        write_sheet = findViewById(R.id.write_sheet);
        analize = findViewById(R.id.analyze);

        mic_choose_tem=findViewById(R.id.mic_choose_tem);
        mic_choose_count=findViewById(R.id.mic_choose_count);
        mic_choose_weight=findViewById(R.id.mic_choose_weight);
        mic_choose_write=findViewById(R.id.mic_choose_write);
        mic_choose_analyze=findViewById(R.id.mic_choose_analyze);
    }
    public TextToSpeech initTalkObject(){
        talk_object = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status == TextToSpeech.SUCCESS){
                    Log.d("success","success");
                    talk_object.setPitch((float)1.0);
                    talk_object.setSpeechRate((float)1.0);
                    Locale locale = Locale.TAIWAN;
                    if(talk_object.isLanguageAvailable(locale) >= TextToSpeech.LANG_AVAILABLE){
                        talk_object.setLanguage(locale);
                    }
                }
            }
        });
        return talk_object;
    }
    public void botSayChinese(final String s){
        talk_object = initTalkObject();
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                talk_object.speak(s,TextToSpeech.QUEUE_FLUSH,null);
                while (talk_object.isSpeaking()){}
            }
        },1500);
    }
    public void buttonevent(){
        mic_choose_tem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //mic_choose_tem.setVisibility(View.INVISIBLE);
                //mic_choose_tem_red.setVisibility(View.VISIBLE);
                talk_object = initTalkObject();
                Chi_recog_result = "心情溫度計";
                botSayChinese(Chi_recog_result);
            }
        });
        mic_choose_count.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //mic_choose_count.setVisibility(View.INVISIBLE);
                //mic_choose_count_red.setVisibility(View.VISIBLE);
                talk_object = initTalkObject();
                Chi_recog_result = "測量步數";
                botSayChinese(Chi_recog_result);
            }
        });
        mic_choose_weight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //mic_choose_weight.setVisibility(View.INVISIBLE);
                //mic_choose_weight_red.setVisibility(View.VISIBLE);
                talk_object = initTalkObject();
                Chi_recog_result = "紀錄體重";
                botSayChinese(Chi_recog_result);
            }
        });
        mic_choose_write.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //mic_choose_write.setVisibility(View.INVISIBLE);
                //mic_choose_write_red.setVisibility(View.VISIBLE);
                talk_object = initTalkObject();
                Chi_recog_result = "分析標準";
                botSayChinese(Chi_recog_result);
            }
        });
        mic_choose_analyze.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //mic_choose_analyze.setVisibility(View.INVISIBLE);
                //mic_choose_analyze_red.setVisibility(View.VISIBLE);
                talk_object = initTalkObject();
                Chi_recog_result = "數據分析";
                botSayChinese(Chi_recog_result);
            }
        });
        count_step.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(Choose.this,Count_step.class);
                startActivity(intent);
            }
        });
        rec_weight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(Choose.this,Recognize_weight.class);
                startActivity(intent);
            }
        });
        write_sheet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(Choose.this,Write_sheet.class);
                startActivity(intent);
            }
        });
        mood_temperature.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(Choose.this,Mood_temperature.class);
                startActivity(intent);
            }
        });
        analize.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(Choose.this,show_analyze_page1.class);
                startActivity(intent);
            }
        });
    }
}